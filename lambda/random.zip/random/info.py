db_host = "RDS endpoint"
db_username = "root"
db_password = "password"
db_name = "random"
db_port = 3306
winner_num = 2
source = "source email"